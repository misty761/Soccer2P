using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeactiveGo : MonoBehaviour
{
    float time;
    public float delay = 3f;

    private void OnEnable()
    {
        time = 0f;
    }

    void Start()
    {
        
    }

    void Update()
    {
        time += Time.deltaTime;
        if (time > delay)
        {
            gameObject.SetActive(false);
        }
    }
}
