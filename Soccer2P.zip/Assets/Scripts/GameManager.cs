using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public GameObject goTittle;
    public GameObject goButtonStart;
    public GameObject goButtonRestart;
    public GameObject goJoysticks;
    public GameObject goScoreNumber1;
    public GameObject goScoreNumber2;
    public GameObject goScoreText1;
    public GameObject goScoreText2;
    public GameObject goTextExplainationToWin;
    public GameObject goTextGoal;
    public GameObject goEffectSpawner;
    
    public int playerSpeed = 6;
    public int playerKickForce = 200;

    public enum State
    {
        Title, Play, End
    }
    public State state;

    // Start is called before the first frame update
    void Start()
    {
        goJoysticks.SetActive(false);
        goScoreNumber1.SetActive(false);
        goScoreNumber2.SetActive(false);
        goScoreText1.SetActive(false);
        goScoreText2.SetActive(false);
        state = State.Title;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void StartGame()
    {
        SoundManager.instance.PlaySound(SoundManager.instance.audioWhistle);
        goTittle.SetActive(false);
        goButtonStart.SetActive(false);
        goJoysticks.SetActive(true);
        goScoreNumber1.SetActive(true);
        goScoreNumber2.SetActive(true);
        goScoreText1.SetActive(true);
        goScoreText2.SetActive(true);
        goTextExplainationToWin.SetActive(true);
        state = State.Play;
    }

    public void GameEnd()
    {
        // play sound
        SoundManager.instance.PlaySound(SoundManager.instance.audioFanfare);
        // show restart button
        goButtonRestart.SetActive(true);
        // hide joysticks
        goJoysticks.SetActive(false);
        // state
        state = State.End;
    }

    public void RestartGame()
    {
        GoogleAd googleAd = FindObjectOfType<GoogleAd>();
        if (googleAd.isLoaded)
        {
            googleAd.ShowAd();
        }
        else
        {
            LoadNewScene();
        }
    }

    public void LoadNewScene()
    {
        SceneManager.LoadScene("Soccer");
    }
}
