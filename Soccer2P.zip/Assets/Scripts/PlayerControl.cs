using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
    public Joystick joystick;
    float h;
    float v;
    public Animator animator;
    bool isMoving;
    Rigidbody2D mRigidbody;
    GameManager gameManager;

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponentInChildren<Animator>();
        isMoving = false;
        mRigidbody = GetComponent<Rigidbody2D>();
        gameManager = FindObjectOfType<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {
        // joystick
        h = joystick.Horizontal;
        v = joystick.Vertical;
        //print("h : " + h);
        //print("v : " + v);

        // moving
        if ((h != 0f || v != 0f) && gameManager.state == GameManager.State.Play)
        {
            // move
            isMoving = true;
            transform.Translate(v * gameManager.playerSpeed * Time.deltaTime * Vector2.up);
            transform.Translate(h * gameManager.playerSpeed * Time.deltaTime * Vector2.right);

            // sprite direction
            float scale = 0.5f;
            float scaleX;
            float scaleY;
            if (h >= 0f)
            {
                scaleX = scale;
            }
            else
            {
                scaleX = -scale;
            }
            if (v >= 0f)
            {
                scaleY = scale;
            }
            else
            {
                //scaleY = -scale;
                scaleY = scale;
            }
            transform.localScale = new Vector2(scaleX, scaleY);


        }
        else
        {
            isMoving = false;
        }

        // animator
        animator.SetBool("Move", isMoving);  
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Ball"))
        {
        // �浹�� ���� ���� ���͸� ���س���.???????
        Vector2 normalVector = collision.contacts[0].normal;
        // add force to ball
        Vector2 force = -gameManager.playerKickForce * normalVector;
        //print(force);
        collision.rigidbody.AddForce(force);
        }
    }
}
