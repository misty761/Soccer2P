using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnEffect : MonoBehaviour
{
    public GameObject[] effects;
    float random;

    private void OnEnable()
    {
        random = Random.Range(0f, 1f);
        if (random > 0.5f)
        {
            int randomEffect = Random.Range(0, effects.Length);
            Instantiate(effects[randomEffect], transform.position, transform.rotation);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
