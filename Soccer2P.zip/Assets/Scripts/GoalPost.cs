using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GoalPost : MonoBehaviour
{
    GameManager gameManager;
    public PlayerControl player;

    // Start is called before the first frame update
    void Start()
    {
        gameManager = FindObjectOfType<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Ball"))
        {
            //print(collision);
            SoundManager.instance.PlaySound(SoundManager.instance.audioClapping);
            gameManager.goTextGoal.SetActive(true);

            // Spawn effects
            gameManager.goEffectSpawner.SetActive(false);
            gameManager.goEffectSpawner.SetActive(true);

            // player's ceremony
            player.animator.SetTrigger("Goal");
        }
    }
}
